export const studiolog = [
    {
        ID: 1,
        FULLNAME: 'SK ash',
        EMAILID: 'skuser@gmail.com',
        CONTACTNO: 9898989898,
        DATEOFVISIT: '4-12-2023',
        MEETINGWITH: 'ARJUN',
    },
    {
        ID: 2,
        FULLNAME: 'PK Photographers',
        EMAILID: 'pkuser@gmail.com',

        CONTACTNO: 9898989898,
        DATEOFVISIT: '7-12-2023',
        MEETINGWITH: 'SHUBHAM',
    },
    {
        ID: 3,
        FULLNAME: 'Mr. XYZ',
        EMAILID: 'xyz@gmail.com',

        CONTACTNO: 9898989898,
        DATEOFVISIT: '9-12-2023',
        MEETINGWITH: 'SAGAR',
    },

    {
        ID: 4,
        FULLNAME: 'Mr. AAXYZ',
        EMAILID: 'sad@gmail.com',

        CONTACTNO: 9898989898,
        DATEOFVISIT: '18-2-2022',
        MEETINGWITH: '+91',
    },
    {
        ID: 5,
        FULLNAME: 'Mr. GGGXYZ',
        EMAILID: 'ahtj@gmail.com',

        CONTACTNO: 9898989898,
        DATEOFVISIT: '2-12-2023',
        MEETINGWITH: 'ASHIF',
    },
    {
        ID: 6,
        FULLNAME: 'SK Photographers',
        EMAILID: 'skuser@gmail.com',

        CONTACTNO: 9898989898,
        DATEOFVISIT: '4-12-2023',
        MEETINGWITH: 'RAM',
    },
    {
        ID: 7,
        FULLNAME: 'PK Photographers',
        EMAILID: 'pkuser@gmail.com',
        CONTACTNO: 9898989898,
        DATEOFVISIT: '7-12-2023',
        MEETINGWITH: '+91',
    },
    {
        ID: 8,
        FULLNAME: 'Mr. XYZ',
        EMAILID: 'xyz@gmail.com',
        CONTACTNO: 9898989898,
        DATEOFVISIT: '9-12-2023',
        MEETINGWITH: '+91',
    },

    {
        ID: 9,
        FULLNAME: 'Mr. AAXYZ',
        EMAILID: 'sad@gmail.com',
        CONTACTNO: 9898989898,
        DATEOFVISIT: '10-12-2023',
        MEETINGWITH: 'VARAD',
    },
    {
        ID: 10,
        FULLNAME: 'Mr. GGGXYZ',
        EMAILID: 'ahtj@gmail.com',
        CONTACTNO: 9898989898,
        DATEOFVISIT: '2-12-2023',
        MEETINGWITH: '+91',
    },
    {
        ID: 11,
        FULLNAME: 'SK Photographers',
        EMAILID: 'skuser@gmail.com',
        CONTACTNO: 9898989898,
        DATEOFVISIT: '4-12-2023',
        MEETINGWITH: '+91',
    },
    {
        ID: 12,
        FULLNAME: 'PK Photographers',
        EMAILID: 'pkuser@gmail.com',
        CONTACTNO: 9898989898,
        DATEOFVISIT: '7-12-2023',
        MEETINGWITH: 'AMIT',
    },
    {
        ID: 13,
        FULLNAME: 'Mr. XYZ',
        EMAILID: 'xyz@gmail.com',
        CONTACTNO: 9898989898,
        DATEOFVISIT: '9-12-2023',
        MEETINGWITH: '+91',
    },
];

export const feedback = [
    {
        ID: 1,
        Feedback: 'SK ash',
    },
    {
        ID: 2,
        Feedback: 'PK Photographers',
    },
    {
        ID: 3,
        Feedback: 'Mr. XYZ',
    }
];

export const Meets = [
    {
        ID: 1,
        NAME: 'abc',
    },
    {
        ID: 2,
        NAME: 'xyz',
    },
    {
        ID: 3,
        NAME: 'lmn',
    },
];





export const check = [
    {
        ID: 1,
        NAME: 'abc',
        COMPANY_NAME: 'uv',
        EMAIL_ID: 'as@gmail.com',
        MOBILE_NO: 7783333333,
        DESIGNATION: 'developer',
        // CODE: 91,
        PURPOSE_OF_VISIT: 'meet',
        MEETING_WITH_ID: 1,
        DATE_OF_VISIT: '2-3-2022',
    },
];

export const visits = [
    {
        ID: 1,
        DATE: '05-04-2023',
        LOCATION: 'India',
        INOUTTIME: '01hrs 00m',
        PURPOSE: 'Capmia Mens Chronograph Watch 44mm 5 ATM',
        MEETINGWITH: 'ABC',
        VISITOR_ID: 3,
    },
    {
        ID: 2,
        DATE: '05-04-2023',
        LOCATION: 'India',
        INOUTTIME: '01hrs 00m',
        PURPOSE: 'Capmia Mens Chronograph Watch 44mm 5 ATM',
        MEETINGWITH: 'ABC',
        VISITOR_ID: 3,
    },
    {
        ID: 3,
        DATE: '05-04-2023',
        LOCATION: 'India',
        INOUTTIME: '01hrs 00m',
        PURPOSE: 'Capmia Mens Chronograph Watch 44mm 5 ATM',
        MEETINGWITH: 'ABC',
        VISITOR_ID: 3,
    },
    {
        ID: 4,
        DATE: '07-04-2023',
        LOCATION: 'India',
        INOUTTIME: '01hrs 00m',
        PURPOSE: 'Capmia Mens Chronograph Watch 44mm 5 ATM',
        MEETINGWITH: 'ABC',
        VISITOR_ID: 4,
    },
    {
        ID: 5,
        DATE: '07-04-2023',
        LOCATION: 'India',
        INOUTTIME: '01hrs 00m',
        PURPOSE: 'Capmia Mens Chronograph Watch 44mm 5 ATM',
        MEETINGWITH: 'ABC',
        VISITOR_ID: 4,
    },
];
