export const OrganizationData = [
    {

        ID: 1,
        NAME: 'Ashif Nadaf',
        WEBSITE: 'https://github.com/ashifnadaf8788',
        BILLING_INFORMATION_ID: '1234',
        ADDRESS_LINE_1: 'shirol',
        ADDRESS_LINE_2: 'shirati',
        CITY: 'miraj',
        COUNTRY: 'india',
        STATE: 'maharashtra',
        PRN: '416103',
        GEO_LOCATION: 'sangli',

    },
    {

        ID: 2,
        NAME: 'Shubham Ingle',
        WEBSITE: 'https://github.com/ashifnadaf8788',
        BILLING_INFORMATION_ID: '5678',
        ADDRESS_LINE_1: 'Shivaji nagar',
        ADDRESS_LINE_2: 'tatyaso patil nagar',
        CITY: 'Jaysingpur',
        COUNTRY: 'india',
        STATE: 'maharashtra',
        PRN: '416103',
        GEO_LOCATION: 'jaysingpur',

    },
    {

        ID: 3,
        NAME: 'Omkar Digambar Bartakke',
        WEBSITE: 'https://github.com/ashifnadaf8788',
        BILLING_INFORMATION_ID: '9101',
        ADDRESS_LINE_1: 'Kavla Naka',
        ADDRESS_LINE_2: 'sambhaji chouk',
        CITY: 'sangli',
        COUNTRY: 'india',
        STATE: 'maharashtra',
        PRN: '416103',
        GEO_LOCATION: 'sangli',

    },
    {

        ID: 4,
        NAME: 'Ashutosh Sutar',
        WEBSITE: 'https://github.com/ashifnadaf8788',
        BILLING_INFORMATION_ID: '8752',
        ADDRESS_LINE_1: 'Kumbhar galli',
        ADDRESS_LINE_2: 'Miraj Road',
        CITY: 'savrde',
        COUNTRY: 'india',
        STATE: 'maharashtra',
        PRN: '416103',
        GEO_LOCATION: 'sangli',

    },
    {

        ID: 5,
        NAME: 'Sagar Shinde',
        WEBSITE: 'https://github.com/ashifnadaf8788',
        BILLING_INFORMATION_ID: '8652',
        ADDRESS_LINE_1: 'shivaji ckouk',
        ADDRESS_LINE_2: 'kolhapur Road',
        CITY: 'miraj',
        COUNTRY: 'india',
        STATE: 'maharashtra',
        PRN: '416103',
        GEO_LOCATION: 'sangli',

    },
    {

        ID: 6,
        NAME: 'Bajrang Kale',
        WEBSITE: 'https://github.com/ashifnadaf8788',
        BILLING_INFORMATION_ID: '9876',
        ADDRESS_LINE_1: 'Ghalwad',
        ADDRESS_LINE_2: 'shirati road',
        CITY: 'Ghalwad',
        COUNTRY: 'india',
        STATE: 'maharashtra',
        PRN: '416103',
        GEO_LOCATION: 'kolhapur',

    },
]