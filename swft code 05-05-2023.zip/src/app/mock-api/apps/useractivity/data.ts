export const useractivity = [
    {
        ID: 1,
        NAME: 'Order Created',
        CONTENT:'Updated by Demo Admin on 5:38:00 PM'
    },
    {
        ID: 2,
        NAME: 'Order Created',
        CONTENT:'Updated by Demo Admin on 6:40:00 PM'
    },
    {
        ID: 3, 
        NAME: 'Order Created',
        CONTENT:'Updated by Demo Admin on 4:30:00 PM'
    },
    
];

