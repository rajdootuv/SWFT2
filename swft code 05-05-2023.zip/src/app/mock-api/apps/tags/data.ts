export const tags = [

    {
        ID : 1,
        TAG_NAME : 'HELLO1'
    },
    {
        ID : 2,
        TAG_NAME : 'HELLO2'
    },
    {
        ID : 3,
        TAG_NAME : 'HELLO3'
    },
    {
        ID : 4,
        TAG_NAME : 'HELLO4'
    },
    {
        ID : 5,
        TAG_NAME : 'HELLO5'
    },
    
];

