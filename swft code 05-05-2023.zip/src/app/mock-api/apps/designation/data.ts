

export const designations = [
    {
        ID: 1,
        NAME: 'Akshaya',
        IS_ACTIVE:true
    },
    {
        ID: 2,
        NAME: 'Akshayaa',
        IS_ACTIVE:true
    },
    {
        ID: 3, 
        NAME: 'Akshaya Jadhav',
        IS_ACTIVE:false
    },
    {
        ID: 4,
        NAME: 'Akshayaa',
        IS_ACTIVE:true
    },
    {
        ID: 5, 
        NAME: 'Akshaya1',
        IS_ACTIVE:false
    },
    {
        ID: 6,
        NAME: 'Shreyaa',
        IS_ACTIVE:true
    },
    {
        ID: 7, 
        NAME: 'Pradnya',
        IS_ACTIVE:false
    },
    {
        ID: 8, 
        NAME: 'Purva',
        IS_ACTIVE:true
    },
    {
        ID: 9, 
        NAME: 'Prachi',
        IS_ACTIVE:false
    },
    {
        ID: 10, 
        NAME: 'Vibhavari',
        IS_ACTIVE:true
    },
    {
        ID: 11, 
        NAME: 'Rutuja',
        IS_ACTIVE:true
    },
    {
        ID: 12, 
        NAME: 'Vaishnavi',
        IS_ACTIVE:false
    },
    
];

