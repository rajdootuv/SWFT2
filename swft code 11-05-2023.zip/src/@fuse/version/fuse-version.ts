import { Version } from '@fuse/version/version';

export const FUSE_VERSION = new Version('17.2.0').full;
