export const properties = [
    {
        ID: 1,
        PROPERTY: 'abc Ganapati Gurav',
        VALUE: '100',
    },
    {
        ID: 2,
        PROPERTY: 'abc',
        VALUE: '1001',
    },
    {
        ID: 3,
        PROPERTY: 'xyz',
        VALUE: '5001',
    },
    {
        ID: 4,
        PROPERTY: 'text',
        VALUE: '701',
    },
    {
        ID: 5,
        PROPERTY: 'color',
        VALUE: '9001',
    },
    {
        ID: 6,
        PROPERTY: 'abc Ganapati Gurav',
        VALUE: '100',
    },
    {
        ID: 7,
        PROPERTY: 'abc',
        VALUE: '1001',
    },
    {
        ID: 8,
        PROPERTY: 'xyz',
        VALUE: '5001',
    },
    {
        ID: 9,
        PROPERTY: 'text',
        VALUE: '701',
    },
    {
        ID: 10,
        PROPERTY: 'color',
        VALUE: '9001',
    },
    {
        ID: 11,
        PROPERTY: 'abc Ganapati Gurav',
        VALUE: '100',
    },
    {
        ID: 12,
        PROPERTY: 'abc',
        VALUE: '1001',
    },
    {
        ID: 13,
        PROPERTY: 'xyz',
        VALUE: '5001',
    },
    {
        ID: 14,
        PROPERTY: 'text',
        VALUE: '701',
    },
    {
        ID: 15,
        PROPERTY: 'color',
        VALUE: '9001',
    },
];