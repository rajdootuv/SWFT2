export const talents = [
    {
        ID: 1,
        NAME: 'SK Photographers',
        EMAIL_ID: 'skuser@gmail.com',
        COMPANY_NAME: 'SK Photographers',
        COUNTRY: 'India',
        CITY: 'Sangli',
        DESIGNATION: 'Photographer',
        ACTIVE: true,
        MOBILE_NO: 9898989898,
        CODE: '+91',
        // DOB:0
        
    },
    {
        ID: 2,
        NAME: 'Masdw Aedefe',
        EMAIL_ID: 'weewd33@gmail.com',
        COMPANY_NAME: 'Uv Techsoft',
        COUNTRY: 'Indonat',
        CITY: 'Kolhapur',
        DESIGNATION: 'Drawing',
        ACTIVE: true,
        MOBILE_NO: 9090123456,
        CODE: '+91',
        // DOB:0
        
    },
    {
        ID: 3,
        NAME: 'Prachi Kothale',
        EMAIL_ID: 'Prachi@gmail.com',
        COMPANY_NAME: 'Uv Techsoft pvt.lmt',
        COUNTRY: 'India',
        CITY: 'Satara',
        DESIGNATION: 'Developer',
        ACTIVE: true,
        MOBILE_NO: 9370179713,
        CODE: '+1',
    },
    {
        ID: 4,
        NAME: 'Demo',
        EMAIL_ID: 'demo@gmail.com',
        COMPANY_NAME: 'demo pvt.lmt',
        COUNTRY: 'Demosa',
        CITY: 'demodi',
        DESIGNATION: 'Demer',
        ACTIVE: false,
        MOBILE_NO: 9323439713,
        CODE: '+14',
    }
];