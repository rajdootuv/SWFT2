export const users = [
    {
        ID: 1,
        NAME: 'Mr. NGG',
        EMAIL_ID: 'ALSKDH123@gmail.com',
        MOBILE_NO: 9898989898,
        DOB: '04-04-2000',
        USER_TYPE: 'Admin',
        CODE: '+91',
        USER_BEONGES_TO: 'regular',
        USER_NAME: 'nilesh',
        PICTURE : ''
    },
    {
        ID: 2,
        NAME: 'prasad bandu patil',
        EMAIL_ID: "nilesh123@gmail.com",
        MOBILE_NO: 9898989898,
        DOB: '04-04-2001',
        USER_TYPE: 'Admin',
        CODE: '+91',
        USER_BEONGES_TO: 'regular',
        USER_NAME: 'nilesh',
        PICTURE : ''
    },
    {
        ID: 3,
        NAME: 'Mr. ASKDJAL',
        EMAIL_ID: 'qwioeu0987@gmail.com',
        MOBILE_NO: 9898989898,
        DOB: '04-04-2003',
        USER_TYPE: 'Admin',
        CODE: '+91',
        USER_BEONGES_TO: 'regular',
        USER_NAME: 'nilesh',
        PICTURE : ''
    },

    {
        ID: 4,
        NAME: 'Mr. AAXYZ',
        EMAIL_ID: 'aoqwiea347@gmail.com',
        MOBILE_NO: 9898989898,
        DOB: '04-04-2000',
        USER_TYPE: 'Admin',
        CODE: '+91',
        USER_BEONGES_TO: 'regular',
        USER_NAME: 'nilesh',
        PICTURE : ''
    },
    {
        ID: 5,
        NAME: 'Mr. GGGXYZ',
        EMAIL_ID: 'ahtj4321@gmail.com',
        MOBILE_NO: 9898989898,
        DOB: '04-04-2000',
        USER_TYPE: 'Admin',
        CODE: '+91',
        USER_BEONGES_TO: 'regular',
        USER_NAME: 'nilesh',
        PICTURE : ''
    },
    
    
];

