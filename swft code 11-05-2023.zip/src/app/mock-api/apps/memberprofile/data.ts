export const MemberProfile = [
    {

        ID: 1,
        NAME:'Brian Hughes',
        EMAIL_ID:'brainhughes@gmail.com',
        PHONE_NO:'8788713736',
        WHATSAPP_NO:'8788713736',
        DATE_OF_BIRTH:'09-07-1999'  ,  
        COMPANY_NAME:'Tata Cunsaltant service' ,
        PERSONAL_IMAGES:'assets/images/avatars/brian-hughes.jpg'

    },
    

]