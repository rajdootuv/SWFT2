export const users = [
    {
        ID: 1,
        FULL_NAME: 'Sagar Shinde',
        ACTIVE_SINCE: 'DEMO',
        LOCATION: 'sangli',
        IP_ADDRESS:'sangli',
        DEVICE:'DEMO'
    },
    {
        ID: 2,
        FULL_NAME: 'Shubham Patil',
        ACTIVE_SINCE: 'DEMO',
        LOCATION: 'Miraj',
        IP_ADDRESS:'Bisur',
        DEVICE:'DEMO'
    },
    {
        ID: 3,
        FULL_NAME: 'Asif Nadaf',
        ACTIVE_SINCE: 'DEMO',
        LOCATION: 'Mumbai',
        IP_ADDRESS:'Satara',
        DEVICE:'DEMO'
    },
    {
        ID: 4,
        FULL_NAME: 'Omkar Bartakee',
        ACTIVE_SINCE: 'DEMO',
        LOCATION: 'delhi',
        IP_ADDRESS:'Pune',
        DEVICE:'DEMO'
    },
    {
        ID: 5,
        FULL_NAME: 'Ajay Kumbhar',
        ACTIVE_SINCE: 'DEMO',
        LOCATION: 'sangli',
        IP_ADDRESS:'Miraj',
        DEVICE:'DEMO'
    },
    

    

    
    
];