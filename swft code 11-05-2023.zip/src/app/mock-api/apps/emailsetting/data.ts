export const EmailSettingData = [
    {

        ID: 1,
        NAME: 'Ashif Nadaf',
        EMAIL_PROVIDER:'ProtonMail',
        EMAIL:'Ashif@gmail.com',
        PASSWORD:12345678,
        OWNER:'Digamber Patil'
        
    },
    {

        ID: 2,
        NAME: 'Shubham Ingle',
        EMAIL_PROVIDER:'Gmail',
        EMAIL:'Shubhamgmail.com',
        PASSWORD:23456781,
        OWNER:'Amit Shaha'
        
    },
    {

        ID: 3,
        NAME: 'Ashutosh Sutar',
        EMAIL_PROVIDER:'Yahoo! Mail',
        EMAIL:'Ashutosh@gmail.com',
        PASSWORD:34567812,
        OWNER:'Narendra Modi'
        
    },
    {

        ID: 4,
        NAME: 'Omkar Bartakke',
        EMAIL_PROVIDER:'GMX',
        EMAIL:'Omkar@gmail.com',
        PASSWORD:45678123,
        OWNER:'Rahul Gandhi'
        
    },
    {

        ID: 5,
        NAME: 'Sagar Shinde',
        EMAIL_PROVIDER:'Mailfence',
        PASSWORD:56781234,
        EMAIL:'Sagar@gmail.com',
        OWNER:'yogi Adityanath'
        
    },
    {

        ID: 6,
        NAME: 'Shubham Patil',
        EMAIL_PROVIDER:'Hushmail',
        PASSWORD:67812345,
        EMAIL:'Shubham@gmail.com',
        OWNER:'baba Ramdev'
        
    },

 
]



