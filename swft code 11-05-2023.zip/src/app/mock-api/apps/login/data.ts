export const logindata = [
    {

      
        ID: 1,
        NAME:'Brian Hughes',
        AVATAR:'assets/images/avatars/brian-hughes.jpg',
        DATE:'653215',
        IPADDRESS:'asdfjhasfdjha',
        LOCATION:'shgdjfh'  ,  
        DEVICEID:'dhgfdstey' 

    },
    {

      
        ID: 2,
        NAME:'Bernard Langley',
        AVATAR: 'assets/images/avatars/male-02.jpg',
        DATE:'653215',
        IPADDRESS:'djghfhj',
        LOCATION:'shgdjfh'  ,  
        DEVICEID:'dhgfdstey' 

    }, {

      
        ID: 3,
        NAME:'Nunez Faulkner',
        AVATAR: 'assets/images/avatars/male-12.jpg',
        DATE:'sdf',
        IPADDRESS:'asdfjhasfdjha',
        LOCATION:'shgdjfh'  ,  
        DEVICEID:'dhgfdstey' 

    }, {

      
        ID: 4,
        NAME:'Edwards Mckenzie',
        AVATAR: 'assets/images/avatars/male-06.jpg',
        DATE:'653215',
        IPADDRESS:'asdfjhasfdjha',
        LOCATION:'fdsf'  ,  
        DEVICEID:'dhgfdstey' 

    }, {

      
        ID: 5,
        NAME:'Elsie Melendez',
        AVATAR: 'assets/images/avatars/female-04.jpg',
        DATE:'653215',
        IPADDRESS:'asdfjhasfdjha',
        LOCATION:'shgdjfh'  ,  
        DEVICEID:'324' 

    }, {

      
        ID: 6,
        NAME:'Joseph Strickland',
        AVATAR: 'assets/images/avatars/male-11.jpg',
        DATE:'653215',
        IPADDRESS:'324',
        LOCATION:'shgdjfh'  ,  
        DEVICEID:'dhgfdstey' 

    }, {

      
        ID: 7,
        NAME: 'Tina Harris',
        AVATAR: 'assets/images/avatars/female-02.jpg',
        DATE:'asd',
        IPADDRESS:'asdfjhasfdjha',
        LOCATION:'shgdjfh'  ,  
        DEVICEID:'dhgfdstey' 

    }, {

      
        ID: 8,
        NAME:'Barber Johnson',
        AVATAR: 'assets/images/avatars/male-09.jpg',
        DATE:'653215',
        IPADDRESS:'asdfjhasfdjha',
        LOCATION:'shgdjfh'  ,  
        DEVICEID:'342' 

    },





    

]