export const customers = [
    {
        ID: 1,
        NAME: 'Mr. NGG',
        EMAIL_ID: 'ALSKDH123@gmail.com',
        MOBILE_NO: 9898989898,
        DOB: '04-04-2000',
        USER_TYPE: 'Admin',
        CODE: '+91',
        LOGO : '',
        IS_WHATSAPP_NO : true,
        CITY : 'Kolhapur',
        COMPONEY_NAME : 'uvtech',
        TAX_NUMBER : '',
        WEBSITE_URL : ''
    },
    {
        ID: 2,
        NAME: 'Mr. prasad',
        EMAIL_ID: 'ALSKDH123@gmail.com',
        MOBILE_NO: 9898989898,
        DOB: '04-04-2000',
        USER_TYPE: 'Admin',
        CODE: '+91',
        LOGO : '',
        IS_WHATSAPP_NO : true,
        CITY : 'Kolhapur',
        COMPONEY_NAME : 'uvtech',
        TAX_NUMBER : '',
        WEBSITE_URL : ''
    },
    {
        ID: 3,
        NAME: 'Mr. kLJls',
        EMAIL_ID: 'ALSKDH123@gmail.com',
        MOBILE_NO: 9898989898,
        DOB: '04-04-2000',
        USER_TYPE: 'Admin',
        CODE: '+91',
        LOGO : '',
        IS_WHATSAPP_NO : true,
        CITY : 'Kolhapur',
        COMPONEY_NAME : 'uvtech',
        TAX_NUMBER : '',
        WEBSITE_URL : ''
    },
    {
        ID: 4,
        NAME: 'Mr. lKSJlsj',
        EMAIL_ID: 'ALSKDH123@gmail.com',
        MOBILE_NO: 9898989898,
        DOB: '04-04-2000',
        USER_TYPE: 'Admin',
        CODE: '+91',
        LOGO : '',
        IS_WHATSAPP_NO : true,
        CITY : 'Kolhapur',
        COMPONEY_NAME : 'uvtech',
        TAX_NUMBER : '',
        WEBSITE_URL : ''
    },

    {
        ID: 5,
        NAME: 'Mr. woieuqweu',
        EMAIL_ID: 'ALSKDH123@gmail.com',
        MOBILE_NO: 9898989898,
        DOB: '04-04-2000',
        USER_TYPE: 'Admin',
        CODE: '+91',
        LOGO : '',
        IS_WHATSAPP_NO : true,
        CITY : 'Kolhapur',
        COMPONEY_NAME : 'uvtech',
        TAX_NUMBER : '',
        WEBSITE_URL : ''
    },
   
    
    
];

