export const selectoptions = [
    {
        ID: 1,
        FIELD_ID: 'Mr. NGG',
        VALUE: 'ALSKDH123@gmail.com',
        HTML:true,
       
    },
    {
        ID: 2,
        FIELD_ID: 'prasad bandu patil',
        VALUE: "nilesh123@gmail.com",
        HTML:true,
       
    },
    {
        ID: 3,
        FIELD_ID: 'Mr. ASKDJAL',
        VALUE: 'qwioeu0987@gmail.com',
        HTML:true,
      
    },

    {
        ID: 4,
        FIELD_ID: 'Mr. AAXYZ',
        VALUE: 'aoqwiea347@gmail.com',
        HTML:true,
       
    },
    {
        ID: 5,
        FIELD_ID: 'Mr. GGGXYZ',
        VALUE: 'ahtj4321@gmail.com',
        HTML: 9898989898,
       
    },
    
    
];

