import { Component } from '@angular/core';

@Component({
  selector: 'app-loginactivity',
  templateUrl: './loginactivity.component.html',
  styleUrls: ['./loginactivity.component.scss']
})
export class LoginactivityComponent {

}
