export class detailView{
    ID:any;
    NAME:string='';
   
}